require('dotenv').config();
const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const prod = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.error('Set SESSION_SECRET to a unique random value of at least 32 characters in .env');
  process.exit(1);
}
if (!process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSWORD.length < 14) {
  console.error('Set ADMIN_PASSWORD to a strong password of at least 14 characters in .env');
  process.exit(1);
}

const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'ekta.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','retailer')),
 status TEXT NOT NULL DEFAULT 'active',
 must_change_password INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS registrations (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 reference TEXT UNIQUE NOT NULL,
 full_name TEXT NOT NULL,
 mobile TEXT NOT NULL,
 shop_name TEXT NOT NULL,
 email TEXT,
 state TEXT NOT NULL,
 city TEXT NOT NULL,
 address TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 user_id INTEGER REFERENCES users(id),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 reviewed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_reg_mobile ON registrations(mobile);
CREATE INDEX IF NOT EXISTS idx_reg_status ON registrations(status);
`);
const adminName = process.env.ADMIN_USERNAME || 'admin';
const existingAdmin = db.prepare("SELECT id FROM users WHERE role='admin' LIMIT 1").get();
if (!existingAdmin) {
  db.prepare('INSERT INTO users(username,password_hash,role) VALUES(?,?,?)')
    .run(adminName, bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12), 'admin');
  console.log(`Bootstrapped admin user: ${adminName}`);
}

app.disable('x-powered-by');
if (prod) app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '20kb' }));
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
  name: 'ekta.sid', secret: process.env.SESSION_SECRET,
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'strict', secure: prod, maxAge: 30 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use('/api/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false }));

const clean = (v, max=200) => String(v ?? '').trim().slice(0, max);
const mobileOk = v => /^[6-9]\d{9}$/.test(v);
const reference = () => 'EE' + crypto.randomBytes(5).toString('hex').toUpperCase();
function requireRole(role) {
  return (req, res, next) => {
    if (!req.session.user || req.session.user.role !== role) return res.status(401).json({ error: 'Please sign in with an authorized account.' });
    next();
  };
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'Ekta Enterprises onboarding portal', aepsTransactionsEnabled: false }));

app.post('/api/register', (req, res) => {
  const full_name = clean(req.body.full_name, 80);
  const mobile = clean(req.body.mobile, 10);
  const shop_name = clean(req.body.shop_name, 100);
  const email = clean(req.body.email, 150);
  const state = clean(req.body.state, 80);
  const city = clean(req.body.city, 80);
  const address = clean(req.body.address, 300);
  if (!full_name || !mobileOk(mobile) || !shop_name || !state || !city || !address) return res.status(400).json({ error: 'Please complete all required fields with valid details.' });
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email address.' });
  const duplicate = db.prepare("SELECT reference FROM registrations WHERE mobile=? AND status!='rejected'").get(mobile);
  if (duplicate) return res.status(409).json({ error: 'A registration request for this mobile already exists.', reference: duplicate.reference });
  let ref = reference();
  while (db.prepare('SELECT 1 FROM registrations WHERE reference=?').get(ref)) ref = reference();
  db.prepare('INSERT INTO registrations(reference,full_name,mobile,shop_name,email,state,city,address) VALUES(?,?,?,?,?,?,?,?)')
    .run(ref, full_name, mobile, shop_name, email || null, state, city, address);
  res.status(201).json({ message: 'Registration received. Wait for admin approval.', reference: ref, status: 'pending' });
});

app.post('/api/status', (req, res) => {
  const ref = clean(req.body.reference, 20).toUpperCase();
  const mobile = clean(req.body.mobile, 10);
  if (!ref || !mobileOk(mobile)) return res.status(400).json({ error: 'Enter the registration reference and registered mobile number.' });
  const r = db.prepare('SELECT reference,status,created_at,reviewed_at FROM registrations WHERE reference=? AND mobile=?').get(ref, mobile);
  if (!r) return res.status(404).json({ error: 'No matching registration found.' });
  res.json(r);
});

app.post('/api/auth/login', (req, res) => {
  const username = clean(req.body.username, 80);
  const password = String(req.body.password ?? '');
  const u = db.prepare('SELECT id,username,password_hash,role,status,must_change_password FROM users WHERE username=?').get(username);
  if (!u || u.status !== 'active' || !bcrypt.compareSync(password, u.password_hash)) return res.status(401).json({ error: 'Invalid username or password.' });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: 'Could not start a secure session.' });
    req.session.user = { id: u.id, username: u.username, role: u.role, mustChangePassword: Boolean(u.must_change_password) };
    res.json({ message: 'Signed in.', user: req.session.user });
  });
});
app.post('/api/auth/logout', (req, res) => req.session.destroy(() => { res.clearCookie('ekta.sid'); res.json({ message: 'Signed out.' }); }));
app.get('/api/auth/me', (req, res) => req.session.user ? res.json({ user: req.session.user }) : res.status(401).json({ error: 'Not signed in.' }));

app.get('/api/admin/registrations', requireRole('admin'), (req, res) => {
  const rows = db.prepare('SELECT reference,full_name,mobile,shop_name,email,state,city,address,status,created_at,reviewed_at FROM registrations ORDER BY id DESC LIMIT 500').all();
  res.json({ registrations: rows });
});
app.post('/api/admin/registrations/:reference/review', requireRole('admin'), (req, res) => {
  const ref = clean(req.params.reference, 20).toUpperCase();
  const decision = clean(req.body.decision, 10);
  if (!['approve','reject'].includes(decision)) return res.status(400).json({ error: 'Decision must be approve or reject.' });
  const r = db.prepare('SELECT * FROM registrations WHERE reference=?').get(ref);
  if (!r) return res.status(404).json({ error: 'Registration not found.' });
  if (r.status !== 'pending') return res.status(409).json({ error: 'This registration has already been reviewed.' });
  if (decision === 'reject') {
    db.prepare("UPDATE registrations SET status='rejected', reviewed_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id);
    return res.json({ message: 'Registration rejected.', reference: ref, status: 'rejected' });
  }
  const username = 'EK' + crypto.randomBytes(4).toString('hex').toUpperCase();
  // A one-time random password is returned only to the authenticated admin after approval.
  // In production, deliver it through a verified channel and force a password change immediately.
  const temporaryPassword = crypto.randomBytes(9).toString('base64url') + 'aA1!';
  const password_hash = bcrypt.hashSync(temporaryPassword, 12);
  const create = db.transaction(() => {
    const info = db.prepare("INSERT INTO users(username,password_hash,role,must_change_password) VALUES(?,?,'retailer',1)").run(username, password_hash);
    db.prepare("UPDATE registrations SET status='approved',user_id=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?").run(info.lastInsertRowid, r.id);
  });
  try { create(); } catch (e) { console.error(e); return res.status(500).json({ error: 'Could not create retailer account.' }); }
  res.json({ message: 'Registration approved. Save these credentials securely; the temporary password will not be shown again.', reference: ref, status: 'approved', loginId: username, temporaryPassword });
});

app.post('/api/retailer/change-password', requireRole('retailer'), (req, res) => {
  const current = String(req.body.currentPassword ?? '');
  const next = String(req.body.newPassword ?? '');
  if (next.length < 12 || next.length > 128) return res.status(400).json({ error: 'New password must be 12–128 characters.' });
  const u = db.prepare('SELECT id,password_hash FROM users WHERE id=? AND role=\'retailer\'').get(req.session.user.id);
  if (!u || !bcrypt.compareSync(current, u.password_hash)) return res.status(401).json({ error: 'Current password is incorrect.' });
  db.prepare('UPDATE users SET password_hash=?,must_change_password=0 WHERE id=?').run(bcrypt.hashSync(next, 12), u.id);
  req.session.user.mustChangePassword = false;
  res.json({ message: 'Password updated.' });
});
app.get('/api/retailer/dashboard', requireRole('retailer'), (req, res) => {
  const r = db.prepare('SELECT reference,status,shop_name,created_at FROM registrations WHERE user_id=?').get(req.session.user.id);
  res.json({ user: req.session.user, registration: r || null, note: 'AEPS transactions are disabled until the authorized provider integration is configured.' });
});

app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Unexpected server error.' }); });
app.listen(PORT, () => console.log(`Ekta Enterprises portal listening on port ${PORT}`));
