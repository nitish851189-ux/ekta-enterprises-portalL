# EKTA ENTERPRISES — AEPS Retailer Portal (Starter)

यह एक backend-enabled starter project है। इसमें registration requests database में save होती हैं, admin login के बाद approval/rejection कर सकता है, और approval पर retailer Login ID तथा one-time temporary password बनता है। यह **अभी live AEPS transaction system नहीं है** और Biznext की API के बिना banking transactions नहीं करेगा।

## चलाने का तरीका

1. कंप्यूटर पर Node.js 20 या नया version install करें।
2. इस folder में terminal खोलें और चलाएँ:
   ```bash
   npm install
   ```
3. `.env.example` की copy बनाकर उसका नाम `.env` रखें। `SESSION_SECRET` में कम-से-कम 32 characters का unique random secret और `ADMIN_PASSWORD` में कम-से-कम 14 characters का मजबूत password डालें।
4. चलाएँ:
   ```bash
   npm start
   ```
5. Browser में `http://localhost:3000` खोलें।

## API endpoints
- `POST /api/register` — retailer registration
- `POST /api/status` — reference + mobile से status check
- `POST /api/auth/login` — admin/retailer login
- `GET /api/admin/registrations` — admin registration list
- `POST /api/admin/registrations/:reference/review` — `{ "decision": "approve" }` या `{ "decision": "reject" }`
- `POST /api/retailer/change-password` — temporary password बदलना
- `GET /api/retailer/dashboard` — retailer dashboard data

## जरूरी production checklist
- HTTPS अनिवार्य करें और secure session store (SQLite/file-based default session store production के लिए पर्याप्त नहीं) configure करें।
- CSRF protection, audit logs, backups, monitoring और deployment secrets configure करें।
- Admin account को सुरक्षित रखें; `.env` और database को public न करें।
- Retailer की अस्थायी password delivery verified/secure channel से करें और first login पर password change enforce करें।
- Aadhaar number, OTP, biometric data, bank PIN या customer banking credentials इस starter में collect न करें।
- वास्तविक AEPS transaction शुरू करने से पहले Biznext की लिखित अनुमति, current API documentation, sandbox credentials, security requirements और compliance approval लें। API keys/passwords chat में share न करें।

## मौजूदा सीमा
`public/index.html` में अभी पहले demo UI का front-end है। Backend endpoints तैयार हैं, लेकिन UI forms अभी API से wired नहीं हैं; frontend integration अगला काम है। इसे live business use में लगाने से पहले developer/security review जरूरी है।
